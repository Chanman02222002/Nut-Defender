input_path = r"C:\Users\Tubam\OneDrive\Desktop\nutdefender\main.py"

try:
    with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()

    with open(input_path, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f"✅ main.py forcibly resaved as UTF-8: {input_path}")
except Exception as e:
    print(f"❌ Failed: {e}")