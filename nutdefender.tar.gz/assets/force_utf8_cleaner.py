import os
from tkinter import filedialog, Tk

def select_main_py():
    root = Tk()
    root.withdraw()
    return filedialog.askopenfilename(
        title="Select your main.py file",
        filetypes=[("Python file", "*.py")]
    )

def force_utf8_clean(input_file):
    output_file = input_file  # overwrite the same file
    try:
        with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
            contents = f.read()
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(contents)
        print(f"✅ main.py was cleaned and saved in UTF-8 encoding.")
    except Exception as e:
        print(f"❌ Error cleaning file: {e}")

if __name__ == "__main__":
    file = select_main_py()
    if file:
        force_utf8_clean(file)
    else:
        print("❌ No file selected.")
